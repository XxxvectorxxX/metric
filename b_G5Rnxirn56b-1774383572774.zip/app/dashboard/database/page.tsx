'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Database, Save, TestTube, AlertCircle, CheckCircle2 } from 'lucide-react'
import { mockDatabaseConfig } from '@/lib/mock-data'
import type { DatabaseConfig } from '@/lib/types'
import { useAuth } from '@/lib/auth-context'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'

export default function DatabaseConfigPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [config, setConfig] = useState<DatabaseConfig>(mockDatabaseConfig)
  const [isTesting, setIsTesting] = useState(false)
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null)
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    if (user?.role !== 'admin') {
      router.push('/dashboard')
    }
  }, [user, router])

  if (user?.role !== 'admin') {
    return null
  }

  async function handleTestConnection() {
    setIsTesting(true)
    setTestResult(null)
    
    // Simulate connection test
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // In demo, check if fields are filled
    if (config.host && config.database && config.username) {
      setTestResult('success')
    } else {
      setTestResult('error')
    }
    setIsTesting(false)
  }

  async function handleSave() {
    setIsSaving(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsSaving(false)
  }

  function updateConfig<K extends keyof DatabaseConfig>(key: K, value: DatabaseConfig[K]) {
    setConfig(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6 pb-20 lg:pb-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Conexao de Banco de Dados</h1>
        <p className="text-sm text-muted-foreground">
          Configure a conexao com o banco de dados externo da sua plataforma de atendimento
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Configuracoes de Conexao
            </CardTitle>
            <CardDescription>
              Insira os dados de acesso ao banco de dados PostgreSQL
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Conexao</Label>
              <Input
                id="name"
                value={config.name}
                onChange={(e) => updateConfig('name', e.target.value)}
                placeholder="Ex: Producao, Desenvolvimento"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="host">Host</Label>
                <Input
                  id="host"
                  value={config.host}
                  onChange={(e) => updateConfig('host', e.target.value)}
                  placeholder="localhost ou IP"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="port">Porta</Label>
                <Input
                  id="port"
                  type="number"
                  value={config.port}
                  onChange={(e) => updateConfig('port', parseInt(e.target.value) || 5432)}
                  placeholder="5432"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="database">Nome do Banco</Label>
              <Input
                id="database"
                value={config.database}
                onChange={(e) => updateConfig('database', e.target.value)}
                placeholder="nome_do_banco"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="username">Usuario</Label>
                <Input
                  id="username"
                  value={config.username}
                  onChange={(e) => updateConfig('username', e.target.value)}
                  placeholder="usuario"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={config.password}
                  onChange={(e) => updateConfig('password', e.target.value)}
                  placeholder="senha"
                />
              </div>
            </div>

            <div className="flex items-center justify-between py-2">
              <div className="space-y-0.5">
                <Label>Conexao SSL</Label>
                <p className="text-xs text-muted-foreground">Recomendado para producao</p>
              </div>
              <Switch
                checked={config.ssl}
                onCheckedChange={(checked) => updateConfig('ssl', checked)}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <div className="space-y-0.5">
                <Label>Conexao Ativa</Label>
                <p className="text-xs text-muted-foreground">Ativar busca de dados</p>
              </div>
              <Switch
                checked={config.isActive}
                onCheckedChange={(checked) => updateConfig('isActive', checked)}
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={handleTestConnection}
                disabled={isTesting}
                className="flex-1"
              >
                <TestTube className="w-4 h-4 mr-2" />
                {isTesting ? 'Testando...' : 'Testar Conexao'}
              </Button>
              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="flex-1"
              >
                <Save className="w-4 h-4 mr-2" />
                {isSaving ? 'Salvando...' : 'Salvar'}
              </Button>
            </div>

            {testResult && (
              <div className={`flex items-center gap-2 p-3 rounded-lg ${
                testResult === 'success' 
                  ? 'bg-green-500/10 text-green-600' 
                  : 'bg-destructive/10 text-destructive'
              }`}>
                {testResult === 'success' ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="text-sm">Conexao bem sucedida!</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4" />
                    <span className="text-sm">Erro na conexao. Verifique os dados.</span>
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardHeader>
            <CardTitle>Query SQL Personalizada</CardTitle>
            <CardDescription>
              Configure a query SQL para buscar os dados dos atendentes. Use :tenantId e :days como parametros.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2 flex-wrap">
              <Badge variant="secondary">:tenantId</Badge>
              <Badge variant="secondary">:days</Badge>
            </div>
            <Textarea
              value={config.customQuery}
              onChange={(e) => updateConfig('customQuery', e.target.value)}
              rows={20}
              className="font-mono text-sm"
              placeholder="SELECT ..."
            />
            <p className="text-xs text-muted-foreground">
              A query deve retornar as colunas: name, pendentes, atendendo, finalizados, total, media_avaliacoes
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
