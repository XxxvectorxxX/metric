'use client'

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import type { User, AuthState } from './types'
import { mockUsers } from './mock-data'

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
  })

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    // Demo: accept any password, find user by email
    const user = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase())
    
    if (user && password.length >= 4) {
      setAuthState({
        user,
        isAuthenticated: true,
      })
      return true
    }
    return false
  }, [])

  const logout = useCallback(() => {
    setAuthState({
      user: null,
      isAuthenticated: false,
    })
  }, [])

  return (
    <AuthContext.Provider value={{ ...authState, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
