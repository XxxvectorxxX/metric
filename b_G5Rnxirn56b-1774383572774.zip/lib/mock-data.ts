import type { AttendantMetrics, User, DatabaseConfig, AppSettings } from './types'

export const mockAttendants: AttendantMetrics[] = [
  { id: '1', name: 'Maria Silva', pendentes: 3, atendendo: 5, finalizados: 142, total: 150, mediaAvaliacoes: 4.8 },
  { id: '2', name: 'João Santos', pendentes: 2, atendendo: 4, finalizados: 128, total: 134, mediaAvaliacoes: 4.6 },
  { id: '3', name: 'Ana Oliveira', pendentes: 5, atendendo: 3, finalizados: 115, total: 123, mediaAvaliacoes: 4.9 },
  { id: '4', name: 'Pedro Costa', pendentes: 1, atendendo: 6, finalizados: 98, total: 105, mediaAvaliacoes: 4.3 },
  { id: '5', name: 'Carla Ferreira', pendentes: 4, atendendo: 2, finalizados: 89, total: 95, mediaAvaliacoes: 4.7 },
  { id: '6', name: 'Lucas Almeida', pendentes: 2, atendendo: 4, finalizados: 76, total: 82, mediaAvaliacoes: 4.5 },
  { id: '7', name: 'Fernanda Lima', pendentes: 3, atendendo: 3, finalizados: 68, total: 74, mediaAvaliacoes: 4.4 },
  { id: '8', name: 'Ricardo Souza', pendentes: 1, atendendo: 5, finalizados: 62, total: 68, mediaAvaliacoes: 4.2 },
  { id: '9', name: 'Juliana Martins', pendentes: 2, atendendo: 2, finalizados: 55, total: 59, mediaAvaliacoes: 4.6 },
  { id: '10', name: 'Bruno Rodrigues', pendentes: 4, atendendo: 1, finalizados: 48, total: 53, mediaAvaliacoes: 4.1 },
]

export const mockUsers: User[] = [
  { id: '1', name: 'Admin', email: 'admin@atendmax.com', role: 'admin', createdAt: new Date('2024-01-01') },
  { id: '2', name: 'Supervisor 1', email: 'supervisor@atendmax.com', role: 'supervisor', createdAt: new Date('2024-02-15') },
  { id: '3', name: 'Usuário 1', email: 'user@atendmax.com', role: 'user', createdAt: new Date('2024-03-10') },
]

export const mockDatabaseConfig: DatabaseConfig = {
  id: '1',
  name: 'Conexão Principal',
  host: '',
  port: 5432,
  database: '',
  username: '',
  password: '',
  ssl: true,
  customQuery: `SELECT 
  u.name,
  COUNT(CASE WHEN t.status = 'pending' THEN 1 END) AS pendentes,
  COUNT(CASE WHEN t.status = 'open' THEN 1 END) AS atendendo,
  COUNT(CASE WHEN t.status = 'closed' THEN 1 END) AS finalizados,
  COUNT(t.id) AS total,
  ROUND(
    AVG(
      CASE 
        WHEN te.evaluation ~ '^[0-9]+(\\.[0-9]+)?$' 
        THEN te.evaluation::numeric
      END
    ), 2
  ) AS media_avaliacoes
FROM "Users" u
LEFT JOIN "Tickets" t 
  ON t."userId" = u.id 
  AND t."tenantId" = :tenantId
  AND t."createdAt" >= NOW() - INTERVAL ':days days'
LEFT JOIN "TicketEvaluations" te 
  ON te."ticketId" = t.id
WHERE 
  u."tenantId" = :tenantId
GROUP BY u.name
ORDER BY total DESC;`,
  isActive: false,
  createdAt: new Date('2024-01-01'),
}

export const mockSettings: AppSettings = {
  refreshInterval: 30,
  dateRangeFilter: 30,
  tenantId: 1,
}

export function getRankedAttendants(attendants: AttendantMetrics[]): AttendantMetrics[] {
  return [...attendants]
    .sort((a, b) => b.total - a.total)
    .map((att, index) => ({ ...att, rank: index + 1 }))
}

// Simulate data updates for demo
export function simulateDataUpdate(attendants: AttendantMetrics[]): AttendantMetrics[] {
  return attendants.map(att => {
    const change = Math.random() > 0.7
    if (!change) return att
    
    const finalizadosIncrease = Math.floor(Math.random() * 3)
    const pendentesChange = Math.random() > 0.5 ? 1 : -1
    const atendendoChange = Math.random() > 0.5 ? 1 : -1
    
    return {
      ...att,
      finalizados: att.finalizados + finalizadosIncrease,
      pendentes: Math.max(0, att.pendentes + pendentesChange),
      atendendo: Math.max(0, att.atendendo + atendendoChange),
      total: att.total + finalizadosIncrease,
      mediaAvaliacoes: att.mediaAvaliacoes 
        ? Math.round((att.mediaAvaliacoes + (Math.random() - 0.5) * 0.1) * 100) / 100 
        : att.mediaAvaliacoes,
    }
  })
}
